<?php
/**
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace CP\Helloworld\Block;

use Magento\Framework\View\Element\Template;

/**
 * Main contact form block
 */
class Helloworld extends Template{
	 public function __construct(Template\Context $context, array $data = [])
    {
        parent::__construct($context, $data);
    } 

	public function getFormAction(){
		return $this->getUrl('helloworld/index/post');
	}

	public function getCollection()
    {

        $post = $this->getRequest()->getPostValue();
        $name=$post["name"];
       	// print_r($post);
       	// print_r($post["name"]);
       	// print_r($post["email"]);
       	// print_r($post["telephone"]);
       	// print_r($post["comment"]);
       	//print_r($post["name"]);
       	//print_r($post["email"]);
       	//print_r($post["telephone"]);
       	//print_r($post["comment"]);
        // echo "<pre>";
         //print_r($post);
        //exit;
        return $post;

    }
}